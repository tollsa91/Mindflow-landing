import React from "react";
import ReactDOM from "react-dom";
import MindFlowLandingPage from "./MindFlowLandingPage";

ReactDOM.render(<MindFlowLandingPage />, document.getElementById("root"));